# -*- coding: utf-8 -*-
"""
Created on Wed Mar  1 20:37:05 2023

@author: 111
"""

import pandas as pd
import csv 
import os

cur_dir = os.path.dirname(os.path.abspath(__file__))  # Path of the current file's directory

path_list = os.listdir(cur_dir, )
path_list.remove("energy_consumption_cal.py")
path_list.remove("bus type.csv")
path_list.remove("Energy Consumption")
path_list.remove("schedule_data1")
path_list.remove("bus_stop_bus_depot.csv")
path_list.remove("bus_2_line_depot.xlsx")

current_file_path = cur_dir.replace("\\", "/")
print(current_file_path)

##############################################################################################
bus_type_df = pd.read_csv("bus type.csv")
bus_type_dict = {}

for i in range(len(bus_type_df)):
    bus_type_dict[bus_type_df["bus_id"][i]] = [bus_type_df["length"][i], bus_type_df["area"][i]]

bus_id_list = [bus_id[:-4] for bus_id in path_list]

for i in bus_id_list:
    list_bus = []
    path = current_file_path + "/" + i + '.csv'
    with open(path, encoding='utf-8') as fp:
          reader = csv.reader(fp)
          header = next(reader)
          for j in reader:
              list_bus.append(j)
    list_bus_new = []   
    
    M_bus1 = 0.7274*float(bus_type_dict[i][0]) + 1.9610*float(bus_type_dict[i][1]) - 11.2174
    M_bus1 = M_bus1*1000 + 25*65
    
    yita = 1.1925
    
    for j in range(len( list_bus )):
        if j == 0:
            xxx = list_bus[j]
            xxx.append(str(0))
            xxx.append(str(0))
            list_bus_new.append(xxx)
        else:
            if  float(list_bus[j][9]) == 0:
                xxx = list_bus[j]
                xxx.append(str(0))
                xxx.append(str(0))
                list_bus_new.append(xxx) 
            else:
                if float(list_bus[j-1][5]) > 0 and float(list_bus[j][5]) > 0:  
                    if float(list_bus[j][8]) == 0:
                        E = 0
                        E1 = 0
                        continue
                    
                    speed = min([float(list_bus[j][9]) / float(list_bus[j][8]),50])
                    d1 = float(list_bus[j][9])
                    F1 =  0.008*M_bus1*9.8 + 0.5*1.18*float(bus_type_dict[i][1]) *speed*speed
                    if list_bus[j][11] == 1:
                        E =  F1*yita*d1 
                    else:
                        E =  F1*yita*d1 + float(list_bus[j][8])*10000

                    E1 =  F1*yita*d1
                    E = E/3600000
                    E1 = E1/3600000
                if float(list_bus[j-1][5]) == 0 and float(list_bus[j][5]) > 0:
                    speed = min([float(list_bus[j][5]),50])
                    d0 = float(list_bus[j][5])*float(list_bus[j][5])/(2*1)
                    d1 = max( [float(list_bus[j][9]) - d0, 0] )
                    F0 = 0.008*M_bus1*9.8 +  0.5*1.18*float(bus_type_dict[i][1])*1*d0 + 1.1*M_bus1*1
                    F1 =  0.008*M_bus1*9.8 + 0.5*1.18*float(bus_type_dict[i][1]) *speed*speed
                    if list_bus[j][11] == 1:
                        E =  F0*yita*d0  + F1*yita*d1 
                    else:
                        E =  F0*yita*d0  + F1*yita*d1 + float(list_bus[j][8])*10000
                   
                    E1 = F0*yita*d0  + F1*yita*d1
                    E = E/3600000
                    E1 = E1/3600000
                if float(list_bus[j-1][5]) >0  and float(list_bus[j][5]) == 0:
                    speed = min( [float(list_bus[j-1][5]),50 ])
                    d2 = float(list_bus[j-1][5])*float(list_bus[j-1][5])/(2*1.5)
                    d1 = max( [float(list_bus[j][9]) - d2, 0] )  
                    F2 = 0.008*M_bus1*9.8 +  0.5*1.18*float(bus_type_dict[i][1])*1.5*d2 - 1.1*M_bus1*1.5
                    F1 =  0.008*M_bus1*9.8 + 0.5*1.18*float(bus_type_dict[i][1]) *speed*speed
                    if list_bus[j][11] == 1:
                        E = F2*yita*d2  + F1*yita*d1 
                    else:
                        E = F2*yita*d2  + F1*yita*d1 + float(list_bus[j][8])*10000
                   
                  
                    E1 = F2*yita*d2  + F1*yita*d1
                    E = E/3600000
                    E1 =E1/3600000
                if float(list_bus[j-1][5]) == 0  and float(list_bus[j][5]) ==  0:
                    if float(list_bus[j][8]) == 0:
                        E = 0
                        E1 = 0
                        continue
                    speed = min([(float(list_bus[j][9]) / float(list_bus[j][8]))*1.5,50])
                    d0 = speed*speed/(2*1)
                    d2 = speed*speed/(2*1.5)
                    d1 = max( [float(list_bus[j][9]) - d0 - d2, 0] )
                    F0 = 0.008*M_bus1*9.8 +  0.5*1.18*float(bus_type_dict[i][1])*1*d0 + 1.1*M_bus1*1
                    F1 =  0.008*M_bus1*9.8 + 0.5*1.18*float(bus_type_dict[i][1]) *speed*speed
                    F2 = 0.008*M_bus1*9.8 +  0.5*1.18*float(bus_type_dict[i][1])*1.5*d2 - 1.1*M_bus1*1.5
                    if list_bus[j][11] == 1:
                        E = F0*yita*d0 + F2*yita*d2  + F1*yita*d1 
                    else:
                        E = F0*yita*d0 + F2*yita*d2  + F1*yita*d1 + float(list_bus[j][8])*10000
                   
                   
                    E1 = F0*yita*d0 + F2*yita*d2  + F1*yita*d1
                    E = E/3600000
                    E1 = E1/3600000
                xxx = list_bus[j]
                xxx.append(str(E))
                xxx.append(str(E1))
                list_bus_new.append(xxx)
                
    
    path = current_file_path + "/Energy Consumption/" + i + '.csv'
    header_new = header
    header_new.append('energy_air')
    header_new.append('energy_no_air')
    with open(path,'w',encoding='utf-8',newline = '') as fp1:
        writer = csv.writer(fp1)
        writer.writerow(header_new)
        writer.writerows(list_bus_new)
        

##############################################################################################################
bus_id_stop_id_df = pd.read_excel("bus_2_line_depot.xlsx")
bus_id_stop_id_dict = {}
for i in range(len(bus_id_stop_id_df)):
    bus_id_stop_id_dict[bus_id_stop_id_df["bus_id"][i]] = [bus_id_stop_id_df["maximum_depot_duraion_index"][i],
                                                                   bus_id_stop_id_df["depot_start_index"][i]]

bus_stop_bus_depot_df = pd.read_csv("bus_stop_bus_depot.csv")
bus_stop_bus_depot_dict = {}
for i in range(len(bus_stop_bus_depot_df)):
    bus_stop_bus_depot_dict[bus_stop_bus_depot_df["id"][i]] = [bus_stop_bus_depot_df["x"][i],
                                                       bus_stop_bus_depot_df["y"][i], 
                                                       bus_stop_bus_depot_df["maximum_duration_label"][i],
                                                       bus_stop_bus_depot_df["bus_depot_id"][i],
                                                       bus_stop_bus_depot_df["distance"][i]]


bus_id_list = [bus_id[:-4] for bus_id in path_list]

header_new = ['max_index','beigntime','endtime','duration','depot_num','dis','energy_air','energy_no_air']
for i in bus_id_list:
    list_bus = []
    
    path = current_file_path + "/Energy Consumption/" + i + '.csv'
    path_new = current_file_path + "/schedule_data1/" + i + '.csv'
        
    with open(path,encoding='utf-8') as fp:
          reader = csv.reader(fp)
          header = next(reader)
          for j in reader:
              list_bus.append(j)
    list_bus_new = [] 
         
    sum_air = 0
    sum_no_air = 0 
    count = 0
    for j in range(1,len( list_bus )):
        if float(list_bus[j][11] ) == 0:
            sum_air = sum_air + float( list_bus[j][14])
            sum_no_air = sum_no_air + float( list_bus[j][15]) 
        if float(list_bus[j][11] ) == 1:
            count = count + 1
            stop_id = int(bus_id_stop_id_dict[i][1]) - 1 + count
            if bus_stop_bus_depot_dict[stop_id][2] != 1 and bus_stop_bus_depot_dict[stop_id][4] > 1:
                sum_air = sum_air + float( list_bus[j][14])
                sum_no_air = sum_no_air + float( list_bus[j][15])  
            if bus_stop_bus_depot_dict[stop_id][2] != 1 and bus_stop_bus_depot_dict[stop_id][4] <= 1:
                list_bus_new.append([0,float( list_bus[j][12]),float( list_bus[j][13]),float( list_bus[j][8]),bus_stop_bus_depot_dict[stop_id][3], bus_stop_bus_depot_dict[stop_id][4], sum_air,sum_no_air]) 
                sum_air = 0
                sum_no_air = 0 
            if bus_stop_bus_depot_dict[stop_id][2] == 1 :
                list_bus_new.append([1,float( list_bus[j][12]),float( list_bus[j][13]),float( list_bus[j][8]),bus_stop_bus_depot_dict[stop_id][3], bus_stop_bus_depot_dict[stop_id][4], sum_air,sum_no_air])
                sum_air = 0
                sum_no_air = 0
    list_bus_new[0][6] =  list_bus_new[0][6] + sum_air 
    list_bus_new[0][7] =  list_bus_new[0][7] + sum_no_air 
  
    list_corrected =[]
    if  len(list_bus_new) == 2:
        list_corrected = list_bus_new
    else:
        if list_bus_new[len(list_bus_new)-1][0] == 1:
          list_corrected = list_bus_new
        else:
            for kk in range(len(list_bus_new)):
                if list_bus_new[kk][0] == 1:
                    break
            list_corrected = list_corrected.append(list_bus_new[kk+1:len(list_bus_new)])
            list_corrected = list_corrected.append(list_bus_new[0:kk + 1])
  
    with open(path_new,'w',encoding='utf-8',newline = '') as fp1:
        writer = csv.writer(fp1)
        writer.writerow(header_new)
        writer.writerows(list_corrected)




